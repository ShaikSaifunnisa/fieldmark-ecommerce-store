# FIELDMARK — E-commerce Website

A 5-page static storefront: Home, Shop (with filtering), Product Detail, Cart, and About.
No backend required — the cart is stored in the browser (localStorage), and product data
lives in `js/products.js`.

## Files
```
fieldmark-store/
├── index.html        Home page
├── shop.html          Product listing + filters (category, price, sort)
├── product.html        Product detail (reads ?id=... , e.g. product.html?id=bp-01)
├── cart.html          Cart + order summary + mock checkout
├── about.html          Brand story page
├── css/style.css      All styling
├── js/products.js     Product catalogue — EDIT THIS to add/remove products
├── js/cart.js         Cart storage logic
└── js/main.js          Shared UI behaviour (mobile nav, product cards, toasts)
```

## Running it
No build step needed. Just open `index.html` in a browser, or serve the folder locally.
Easiest ways to preview:
- **VS Code + Live Server extension** — right-click `index.html` → "Open with Live Server"
- Or just double-click `index.html` to open it directly in a browser

## Editing products
Open `js/products.js` and edit the `PRODUCTS` array. Each product needs an `id`,
`name`, `category`, `price`, `seed` (used to generate a photo), `sizes`, `short`
description, and a `details` list. Every page reads from this one file.

## Product photos
Images come from `picsum.photos`, a free placeholder photo service — each product's
`seed` value generates a consistent photo for that product across pages. To use your
own product photography instead, replace the `productImage()` function in
`js/products.js` with your own image URLs or local file paths.

## Which apps to build/host this with

**To edit the code**
- **VS Code** (free, desktop) — the standard choice; install the "Live Server"
  extension to preview changes instantly as you edit
- **Replit** or **CodeSandbox** (browser-based, works on any device including a
  phone/Chromebook — no install needed) if you don't have a laptop handy
- **GitHub Codespaces** — full VS Code in the browser, connected to a GitHub repo

**To put it online for free**
- **GitHub Pages** — push this folder to a GitHub repo, enable Pages in repo
  settings, done. Good for a permanent free URL to put on a resume.
- **Netlify** or **Vercel** — drag-and-drop the folder (or connect a GitHub repo)
  for a live URL in under a minute; both also give you free custom subdomains
  and automatic redeploys on every git push

**To version control it**
- **Git + GitHub** — even for a solo project, commit as you go so you have a
  history and can show the repo to recruiters

## Next steps if you want to take this further
- Swap the mock checkout for a real payment gateway (Razorpay is the common
  choice for INR pricing; Stripe for international)
- Move `PRODUCTS` from a JS file into a real database (Firebase/Supabase are
  free-tier friendly and need no server setup)
- Add user accounts and order history
- Add a real search bar (currently the site only filters by category/price)
